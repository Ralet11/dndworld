// app/src/api/scenarios.js
import { apiClient } from './client'

// images: [{ url, label?, sortOrder }]
export async function addScenarioImages(scenarioId, images) {
  const { data } = await apiClient.post(`/scenarios/${scenarioId}/images`, { images })
  return data
}