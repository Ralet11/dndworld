"use client"

// app/src/pages/dm/DMScenariosPage.jsx
import { useEffect, useMemo, useState } from "react"
import { useSessionStore } from "../../store/useSessionStore"
import { useCampaignSession } from "../../hooks/useCampaignSession"
import { createScenario } from "../../api/campaigns"
import ScenarioImageEditor from "../../components/scenarios/ScenarioImageEditor"
import SearchSelect from "../../components/common/SearchSelect"

const newScenarioInitial = {
  title: "",
  summary: "",
  objective: "",
  environmentTags: "",
}

const DMScenariosPage = () => {
  const session = useSessionStore((s) => s.session)
  const activeCampaignId = session.activeCampaignId
  const { campaign, isLoading, error, refetch } = useCampaignSession(activeCampaignId, { role: "dm" })

  const scenarios = campaign?.scenarios ?? []
  const npcs = campaign?.npcs ?? []
  const items = campaign?.items ?? []

  const [selectedScenarioId, setSelectedScenarioId] = useState(null)
  const [creating, setCreating] = useState(false)
  const [createError, setCreateError] = useState("")
  const [form, setForm] = useState(newScenarioInitial)
  const [note, setNote] = useState("")

  useEffect(() => {
    if (!selectedScenarioId && scenarios.length) {
      setSelectedScenarioId(scenarios[0].id)
    }
  }, [scenarios, selectedScenarioId])

  const selectedScenario = useMemo(
    () => scenarios.find((s) => s.id === selectedScenarioId) ?? null,
    [scenarios, selectedScenarioId],
  )

  const handleFormChange = (e) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
    if (createError) setCreateError("")
  }

  const createNewScenario = async (e) => {
    e.preventDefault()
    if (!activeCampaignId) return
    if (!form.title.trim()) {
      setCreateError("El título es obligatorio.")
      return
    }
    setCreating(true)
    setCreateError("")
    try {
      const payload = {
        title: form.title.trim(),
      }
      if (form.summary.trim()) payload.summary = form.summary.trim()
      if (form.objective.trim()) payload.objective = form.objective.trim()
      if (form.environmentTags.trim()) {
        payload.environmentTags = form.environmentTags
          .split(",")
          .map((t) => t.trim())
          .filter(Boolean)
      }
      await createScenario(activeCampaignId, payload)
      setForm(newScenarioInitial)
      await refetch()
    } catch (err) {
      setCreateError(err?.response?.data?.message || err?.message || "No se pudo crear el escenario.")
    } finally {
      setCreating(false)
    }
  }

  useEffect(() => {
    if (!selectedScenarioId) return
    const key = `note:${selectedScenarioId}`
    const stored = localStorage.getItem(key)
    if (stored) setNote(stored)
    else setNote("")
  }, [selectedScenarioId])

  const saveNoteLocal = () => {
    if (!selectedScenarioId) return
    localStorage.setItem(`note:${selectedScenarioId}`, note)
  }

  return (
    <div className="grid grid-cols-12 gap-8 p-6">
      <aside className="col-span-3">
        <div className="gaming-card p-6 space-y-6">
          <header className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
              <p className="text-xs uppercase tracking-[0.2em] text-primary font-semibold">Campaña Activa</p>
            </div>
            <h2 className="text-xl font-bold text-text-primary font-display">{campaign?.name || "Sin campaña"}</h2>
          </header>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-xs uppercase tracking-[0.15em] text-text-muted font-semibold">Escenarios</p>
              <div className="gaming-badge">{scenarios.length}</div>
            </div>

            <div className="max-h-[50vh] space-y-3 overflow-auto pr-2 scrollbar-thin scrollbar-track-surface scrollbar-thumb-border">
              {isLoading && (
                <div className="flex items-center gap-3 p-4 gaming-card">
                  <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                  <span className="text-sm text-text-secondary">Cargando escenarios...</span>
                </div>
              )}

              {error && (
                <div className="p-4 gaming-card border-danger bg-danger/10">
                  <p className="text-sm text-danger">{error.message || "Error al cargar"}</p>
                </div>
              )}

              {scenarios.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSelectedScenarioId(s.id)}
                  className={`w-full p-4 rounded-xl border transition-all duration-300 text-left group ${
                    selectedScenarioId === s.id
                      ? "border-primary bg-primary/10 shadow-lg gaming-glow"
                      : "border-border bg-surface-elevated hover:border-border-hover hover:bg-surface-interactive"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <h3
                        className={`font-semibold text-sm line-clamp-1 ${
                          selectedScenarioId === s.id ? "text-primary text-glow" : "text-text-primary"
                        }`}
                      >
                        {s.title}
                      </h3>
                      {s.summary && <p className="mt-2 line-clamp-2 text-xs text-text-muted">{s.summary}</p>}
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <div className="gaming-badge text-[10px]">{s.images?.length ?? 0} IMG</div>
                    </div>
                  </div>
                </button>
              ))}

              {!scenarios.length && !isLoading && (
                <div className="p-6 text-center gaming-card border-dashed">
                  <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-surface-interactive flex items-center justify-center">
                    <svg className="w-6 h-6 text-text-muted" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 6v6m0 0v6m0-6h6m-6 0H6"
                      />
                    </svg>
                  </div>
                  <p className="text-sm text-text-muted">No hay escenarios aún</p>
                  <p className="text-xs text-text-subtle mt-1">Crea tu primer escenario abajo</p>
                </div>
              )}
            </div>
          </div>

          <div className="gaming-card p-4 border-secondary/30 bg-secondary/5">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-2 h-2 bg-secondary rounded-full animate-pulse"></div>
              <p className="text-xs uppercase tracking-[0.15em] text-secondary font-semibold">Nuevo Escenario</p>
            </div>

            <form className="space-y-3" onSubmit={createNewScenario}>
              <input
                name="title"
                placeholder="Título del escenario"
                value={form.title}
                onChange={handleFormChange}
                className="gaming-input"
                required
              />
              <textarea
                name="summary"
                placeholder="Resumen breve"
                rows={3}
                value={form.summary}
                onChange={handleFormChange}
                className="gaming-input resize-none"
              />
              <input
                name="objective"
                placeholder="Objetivo principal"
                value={form.objective}
                onChange={handleFormChange}
                className="gaming-input"
              />
              <input
                name="environmentTags"
                placeholder="Etiquetas (separadas por coma)"
                value={form.environmentTags}
                onChange={handleFormChange}
                className="gaming-input"
              />

              {createError && (
                <div className="p-3 rounded-lg bg-danger/10 border border-danger/30">
                  <p className="text-xs text-danger">{createError}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={creating}
                className="w-full gaming-button-secondary disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {creating ? (
                  <span className="flex items-center justify-center gap-2">
                    <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                    Creando...
                  </span>
                ) : (
                  "Crear Escenario"
                )}
              </button>
            </form>
          </div>
        </div>
      </aside>

      <section className="col-span-6 space-y-6">
        <header className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 bg-accent rounded-full animate-pulse"></div>
            <p className="text-sm uppercase tracking-[0.15em] text-accent font-semibold">Mesa de Juego</p>
          </div>
          <h1 className="font-display text-4xl font-bold text-text-primary text-glow">
            {selectedScenario?.title || "Selecciona un Escenario"}
          </h1>
          <p className="text-text-secondary max-w-2xl leading-relaxed">
            {selectedScenario?.summary ||
              "Aquí verás la imagen activa del escenario. Esta es el área central donde tus jugadores experimentarán la aventura."}
          </p>
        </header>

        <div className="scenario-viewer gaming-glow">
          {selectedScenario?.images?.length ? (
            <img
              src={selectedScenario.images[0].url || "/placeholder.svg"}
              alt={selectedScenario.images[0].label || "Escenario"}
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center">
              <div className="text-center space-y-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-surface-interactive flex items-center justify-center">
                  <svg className="w-8 h-8 text-text-muted" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                    />
                  </svg>
                </div>
                <div>
                  <p className="text-text-secondary font-medium">Sin imágenes de escenario</p>
                  <p className="text-sm text-text-muted mt-1">Agrega imágenes desde el panel lateral</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {selectedScenario && (
          <div className="gaming-card p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-accent rounded-full"></div>
                <h3 className="text-lg font-semibold text-text-primary">Notas del Escenario</h3>
              </div>
              <button onClick={saveNoteLocal} className="gaming-button text-xs px-3 py-1">
                Guardar Notas
              </button>
            </div>
            <textarea
              rows={5}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Pistas secretas, giros de la trama, diálogos importantes, reglas especiales..."
              className="gaming-input resize-none"
            />
          </div>
        )}
      </section>

      <aside className="col-span-3 space-y-6">
        <div className="gaming-card p-6">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
            <p className="text-xs uppercase tracking-[0.15em] text-primary font-semibold">Galería de Imágenes</p>
          </div>
          {!selectedScenario ? (
            <div className="text-center py-8">
              <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-surface-interactive flex items-center justify-center">
                <svg className="w-6 h-6 text-text-muted" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
              </div>
              <p className="text-sm text-text-muted">Selecciona un escenario</p>
            </div>
          ) : (
            <ScenarioImageEditor scenario={selectedScenario} onChanged={refetch} />
          )}
        </div>

        {selectedScenario && (
          <div className="gaming-card p-6">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-2 h-2 bg-secondary rounded-full animate-pulse"></div>
              <p className="text-xs uppercase tracking-[0.15em] text-secondary font-semibold">
                Elementos del Escenario
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-text-secondary mb-2">NPCs Disponibles</label>
                <SearchSelect
                  placeholder="Buscar NPCs..."
                  options={npcs.map((n) => ({ value: n.id, label: n.name }))}
                  onSelect={(opt) => {
                    console.log("asociar npc", opt, "->", selectedScenario.id)
                  }}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-text-secondary mb-2">Objetos Disponibles</label>
                <SearchSelect
                  placeholder="Buscar objetos..."
                  options={items.map((it) => ({ value: it.id, label: it.name }))}
                  onSelect={(opt) => {
                    console.log("asociar item", opt, "->", selectedScenario.id)
                  }}
                />
              </div>
            </div>

            <div className="mt-6 p-3 rounded-lg bg-surface border border-border/50">
              <p className="text-xs text-text-subtle">
                💡 <strong>Tip:</strong> Los elementos asociados aparecerán automáticamente cuando actives este
                escenario en la mesa de juego.
              </p>
            </div>
          </div>
        )}
      </aside>
    </div>
  )
}

export default DMScenariosPage
