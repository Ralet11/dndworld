"use client"

// app/src/components/dm/DMSidebar.jsx
import { NavLink, useNavigate } from "react-router-dom"
import { useSessionStore } from "../../store/useSessionStore"

const DMSidebar = () => {
  const navigate = useNavigate()
  const session = useSessionStore((s) => s.session)

  const goToCampaignPicker = () => navigate("/dm")

  return (
    <div className="h-full p-6">
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
          <p className="text-xs uppercase tracking-[0.2em] text-primary font-semibold">Campaña Activa</p>
        </div>
        <div className="gaming-card p-4 border-primary/20 bg-primary/5">
          <h2 className="text-lg font-bold text-text-primary mb-3 font-display">
            {session.campaigns.find((c) => c.id === session.activeCampaignId)?.name || "Sin campaña"}
          </h2>
          <button type="button" onClick={goToCampaignPicker} className="gaming-button text-xs px-3 py-2 w-full">
            Cambiar Campaña
          </button>
        </div>
      </div>

      <nav className="space-y-2">
        <div className="mb-4">
          <p className="text-xs uppercase tracking-[0.15em] text-text-muted font-semibold mb-3">Herramientas DM</p>
        </div>

        <NavLink to="/dm" className={({ isActive }) => `gaming-nav-item ${isActive ? "active" : ""}`} end>
          <div className="flex items-center gap-3">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
              />
            </svg>
            Campañas
          </div>
        </NavLink>

        <NavLink to="/dm/tools/scenarios" className={({ isActive }) => `gaming-nav-item ${isActive ? "active" : ""}`}>
          <div className="flex items-center gap-3">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
              />
            </svg>
            Escenarios
          </div>
        </NavLink>

        <NavLink to="/dm/tools/characters" className={({ isActive }) => `gaming-nav-item ${isActive ? "active" : ""}`}>
          <div className="flex items-center gap-3">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"
              />
            </svg>
            NPCs
          </div>
        </NavLink>

        <NavLink to="/dm/tools/items" className={({ isActive }) => `gaming-nav-item ${isActive ? "active" : ""}`}>
          <div className="flex items-center gap-3">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"
              />
            </svg>
            Objetos
          </div>
        </NavLink>
      </nav>

      <div className="mt-auto pt-8">
        <div className="gaming-card p-4 border-accent/20 bg-accent/5">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
            <p className="text-xs uppercase tracking-[0.15em] text-accent font-semibold">Estado del Sistema</p>
          </div>
          <p className="text-xs text-text-muted">Todas las herramientas operativas</p>
        </div>
      </div>
    </div>
  )
}

export default DMSidebar
