// app/src/layouts/DMShell.jsx
import { Outlet, Navigate, NavLink, useNavigate } from "react-router-dom"
import { useEffect } from "react"
import { useSessionStore } from "../store/useSessionStore"
import DMSidebar from "../pages/dm/DMSidebar"

const DMShell = () => {
  const navigate = useNavigate()
  const session = useSessionStore((s) => s.session)

  // si no hay campaña activa, podés redirigir a /dm o mostrar aviso:
  useEffect(() => {
    if (!session?.activeCampaignId) {
      // navigate("/dm");  // opcional
    }
  }, [session?.activeCampaignId, navigate])

  return (
    <div className="min-h-screen bg-midnight text-slate-100 flex">
      <DMSidebar />
      <main className="flex-1 p-6">
        <Outlet />
      </main>
    </div>
  )
}

export default DMShell
